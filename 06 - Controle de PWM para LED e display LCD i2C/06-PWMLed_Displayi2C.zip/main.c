#include <stdio.h>
#include "driver/ledc.h"
#include "esp_err.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

//Mais bibliotecas

#include "esp_timer.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_ops.h"
#include "driver/i2c.h"
#include "esp_log.h"
#include "lvgl.h"
#include "esp_lvgl_port.h"

//biblioteca de felipe
#include "int_i2c.h"


//LEDS
#define LED_VERDE 4
#define LED_AMARELO 5
#define LED_AZUL 6
#define LED_BRANCO 7

#define LED_PWM 3          // Pino do LED (GPIO 3)
#define LEDC_TIMER LEDC_TIMER_0      // Timer do PWM
#define LEDC_MODE LEDC_LOW_SPEED_MODE // Modo de velocidade do PWM
#define LEDC_CHANNEL LEDC_CHANNEL_0  // Canal do PWM
#define LEDC_DUTY_RES LEDC_TIMER_13_BIT // Resolução do duty cycle (13 bits)
#define LEDC_FREQUENCY 2000          // Frequência do PWM (2000 Hz)

//BOTOES

#define BOTAO_VERDE 1 //BOTAO A
#define BOTAO_AMARELO 2 //BOTAO B
TickType_t xTaskGetTickCount(void);


/* Configuração Pull-DOWN */ 
//pra acionar quando o botao for pressionado

void configure_botao(int botao_pin) {
    gpio_set_direction(botao_pin, GPIO_MODE_INPUT);
    gpio_pullup_dis(botao_pin);     // Desativa o pull-up interno
    gpio_pulldown_en(botao_pin);    // Ativa o pull-down interno
}

void pwm_init() {
    // Configura o timer do PWM
    ledc_timer_config_t timer_config = {
        .speed_mode = LEDC_MODE,
        .duty_resolution = LEDC_DUTY_RES,
        .timer_num = LEDC_TIMER,
        .freq_hz = LEDC_FREQUENCY,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ESP_ERROR_CHECK(ledc_timer_config(&timer_config));

    // Configura o canal do PWM
    ledc_channel_config_t channel_config = {
        .gpio_num = LED_PWM,
        .speed_mode = LEDC_MODE,
        .channel = LEDC_CHANNEL,
        .timer_sel = LEDC_TIMER,
        .duty = 0, // Duty cycle inicial (0%)
        .hpoint = 0,
    };
    ESP_ERROR_CHECK(ledc_channel_config(&channel_config));
}

void set_led_brightness(uint32_t duty) {
    // Define o duty cycle do PWM
    ESP_ERROR_CHECK(ledc_set_duty(LEDC_MODE, LEDC_CHANNEL, duty));
    // Atualiza o duty cycle
    ESP_ERROR_CHECK(ledc_update_duty(LEDC_MODE, LEDC_CHANNEL));
}

void app_main() {
    // Configure Digital I/O for LEDs
    gpio_set_direction(LED_VERDE, GPIO_MODE_OUTPUT);
    gpio_set_direction(LED_AMARELO, GPIO_MODE_OUTPUT);
    gpio_set_direction(LED_AZUL, GPIO_MODE_OUTPUT);
    gpio_set_direction (LED_BRANCO, GPIO_MODE_OUTPUT);

    
    // Inicializa o PWM
    pwm_init();

    

  //variaveis
  uint8_t contador = 0;
  uint8_t passo = 1; // incrementar 1 

  uint32_t VERDE_PRESSIONADO = 0;   
  uint32_t AMARELO_PRESSIONADO = 0; 
  const uint32_t debounce_time = 200 / portTICK_PERIOD_MS; // Tempo de debounce


    // Define o valor máximo do duty cycle (2^13 - 1 = 8191)
    uint32_t max_duty = (1 << LEDC_DUTY_RES) - 1;

    while (1) {
        //Funcao do PWM
        // Aumenta o brilho do LED
        for (int duty = 0; duty < max_duty; duty += 100) {
            set_led_brightness(duty);
            vTaskDelay(pdMS_TO_TICKS(10)); // Aguarda 10 ms
        }

        // Diminui o brilho do LED
        for (int duty = max_duty; duty > 0; duty -= 100) {
            set_led_brightness(duty);
            vTaskDelay(pdMS_TO_TICKS(10)); // Aguarda 10 ms
        }
      //Fim do Led Azul como PWM  
      
      // Modulo do contador 4 bit
    // Leitura atual dos botões (0 se pressionado, 1 se não)
    int VERDE_ATUAL = gpio_get_level(BOTAO_VERDE);
    int AMARELO_ATUAL = gpio_get_level(BOTAO_AMARELO);

    // Verifica o botão verde
   if (VERDE_ATUAL == 0 && (xTaskGetTickCount() - VERDE_PRESSIONADO) > debounce_time) {
    // Incrementa contador com a unidade atual
      contador += passo;
      // Lógica de estouro (overflow)
      if (contador > 0xF) {
          contador = contador % 0x10; // Mantém dentro do intervalo de 4 bits
          }
          VERDE_PRESSIONADO = xTaskGetTickCount(); 
    }
  // Verifica o botão amarelo
     if (AMARELO_ATUAL == 0 && (xTaskGetTickCount() - AMARELO_PRESSIONADO) > debounce_time)  {         // Alterna unidade de incremento entre 1 e 2
            passo = (passo == 1) ? 2 : 1;
            AMARELO_PRESSIONADO = xTaskGetTickCount(); // Atualiza o tempo do último acionamento
        }

    // Atualiza os LEDs de acordo com o valor do contador
      gpio_set_level(LED_BRANCO, (contador & 0x01));         // LED Branco - Bit 3 (MSB)
      gpio_set_level(LED_AZUL, (contador & 0x02) >> 1);      // LED Azul - Bit 2
      gpio_set_level(LED_AMARELO, (contador & 0x04) >> 2);   // LED Amarelo - Bit 1
      gpio_set_level(LED_VERDE, (contador & 0x08) >> 3);     // LED Verde - Bit 0 (LSB)
    
    // Incrementa o contador e faz um loop de 4 bits
      contador = (contador + 1) % 16; // 16 = 2^4 

    //Fim do contador 4 bit

    //Display Oled

    //Fim do display Oled



    }
}